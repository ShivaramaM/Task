function setReminder() {
    const day = document.getElementById('day').value;
    const time = document.getElementById('time').value;
    const activity = document.getElementById('activity').value;

    if (!time) {
        alert('Please select a time.');
        return;
    }

    const reminderTime = new Date();
    const [hours, minutes] = time.split(':');
    reminderTime.setHours(hours);
    reminderTime.setMinutes(minutes);
    reminderTime.setSeconds(0);

    const now = new Date();
    const timeUntilReminder = reminderTime.getTime() - now.getTime();

    if (timeUntilReminder < 0) {
        alert('The selected time is in the past. Please select a future time.');
        return;
    }

    setTimeout(() => {

        playAlarmSound();
    }, timeUntilReminder);

    alert(`Reminder set for ${activity} on ${day} at ${time}`);
}

function playAlarmSound() {
    const alarmSound = document.getElementById('alarm-sound');
    alarmSound.play();
}
